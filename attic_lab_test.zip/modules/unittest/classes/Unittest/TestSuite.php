<?php defined('SYSPATH') OR die('No direct script access.');

class Unittest_TestSuite extends Kohana_Unittest_TestSuite {}
