<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Image extends Kohana_Image {}
