<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Kohana Cache Exception
 * 
 * @package    Kohana/Cache
 * @category   Base
 * @author     Kohana Team
 * @copyright  (c) 2009-2012 Kohana Team
 * @license    http://kohanaphp.com/license
 */
class Kohana_Cache_Exception extends Kohana_Exception {}
