<?php defined('SYSPATH') or die('No direct script access.');

abstract class Kodoc_Missing extends Kohana_Kodoc_Missing {  }
