<?php defined('SYSPATH') OR die('No direct access allowed.');

class Kohana_Mango_Exception extends Kohana_Exception {}