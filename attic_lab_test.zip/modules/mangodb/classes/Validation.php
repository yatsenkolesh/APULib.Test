<?php defined('SYSPATH') OR die('No direct access allowed.');

class Validation extends Mango_Validation {}