<?php

class Mango_Iterator extends Kohana_Mango_Iterator {}