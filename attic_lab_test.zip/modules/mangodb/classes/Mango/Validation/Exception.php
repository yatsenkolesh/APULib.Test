<?php defined('SYSPATH') or die('No direct script access.');

class Mango_Validation_Exception extends Kohana_Mango_Validation_Exception {}