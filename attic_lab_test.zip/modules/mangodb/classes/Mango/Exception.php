<?php

class Mango_Exception extends Kohana_Mango_Exception {}