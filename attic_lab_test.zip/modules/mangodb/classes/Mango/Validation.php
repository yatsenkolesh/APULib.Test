<?php

class Mango_Validation extends Kohana_Mango_Validation {}