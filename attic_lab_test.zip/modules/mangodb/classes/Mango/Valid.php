<?php

class Mango_Valid extends Kohana_Mango_Valid {}