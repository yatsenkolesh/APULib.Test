<?php

class Mango_Array extends Kohana_Mango_Array {}