<?php defined('SYSPATH') OR die('No direct script access.');

class Config_Group extends Kohana_Config_Group {}
